package org.example.karaokeapp.model;

public class Booking {
    private String idBooking, room, durasi, customer, subtotal;

    public Booking(String idBooking, String room, String durasi, String customer, String subtotal) {
        this.idBooking = idBooking;
        this.room = room;
        this.durasi = durasi;
        this.customer = customer;
        this.subtotal = subtotal;
    }

    public String getIdBooking() { return idBooking; }
    public String getRoom() { return room; }
    public String getDurasi() { return durasi; }
    public String getCustomer() { return customer; }
    public String getSubtotal() { return subtotal; }
}