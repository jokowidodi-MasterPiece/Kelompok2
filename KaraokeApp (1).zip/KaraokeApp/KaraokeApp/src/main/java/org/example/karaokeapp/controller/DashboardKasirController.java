package org.example.karaokeapp.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import org.example.karaokeapp.model.Booking;
import org.example.karaokeapp.model.Transaksi;

import java.io.IOException;

public class DashboardKasirController {

    @FXML private Label namaLabel, roleLabel, loginTerakhirLabel;
    @FXML private Label roomTerpakaiLabel, roomKosongLabel, totalBookingLabel;

    @FXML private TableView<Transaksi> tableTransaksi;
    @FXML private TableColumn<Transaksi, String> colIdTransaksi, colRoomTransaksi, colDurasiTransaksi, colCustomerTransaksi, colSubtotalTransaksi;
    @FXML private TableColumn<Transaksi, Void> colActionTransaksi;

    @FXML private TableView<Booking> tableBooking;
    @FXML private TableColumn<Booking, String> colIdBooking, colRoomBooking, colDurasiBooking, colCustomerBooking, colSubtotalBooking;
    @FXML private TableColumn<Booking, Void> colActionBooking;

    @FXML
    public void initialize() {
        setupTransaksiTable();
        setupBookingTable();
        loadDummyData(); // TODO: ganti dengan data dari database
    }

    private void setupTransaksiTable() {
        colIdTransaksi.setCellValueFactory(new PropertyValueFactory<>("idTransaksi"));
        colRoomTransaksi.setCellValueFactory(new PropertyValueFactory<>("room"));
        colDurasiTransaksi.setCellValueFactory(new PropertyValueFactory<>("durasi"));
        colCustomerTransaksi.setCellValueFactory(new PropertyValueFactory<>("customer"));
        colSubtotalTransaksi.setCellValueFactory(new PropertyValueFactory<>("subtotal"));

        colActionTransaksi.setCellFactory(new Callback<>() {
            @Override
            public TableCell<Transaksi, Void> call(TableColumn<Transaksi, Void> param) {
                return new TableCell<>() {
                    private final Button btn = new Button("Tambah Order");
                    {
                        btn.getStyleClass().add("btn-table-action");
                        btn.setOnAction(e -> handleTambahOrder(getTableView().getItems().get(getIndex())));
                    }
                    @Override
                    protected void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        setGraphic(empty ? null : btn);
                    }
                };
            }
        });
    }

    private void setupBookingTable() {
        colIdBooking.setCellValueFactory(new PropertyValueFactory<>("idBooking"));
        colRoomBooking.setCellValueFactory(new PropertyValueFactory<>("room"));
        colDurasiBooking.setCellValueFactory(new PropertyValueFactory<>("durasi"));
        colCustomerBooking.setCellValueFactory(new PropertyValueFactory<>("customer"));
        colSubtotalBooking.setCellValueFactory(new PropertyValueFactory<>("subtotal"));

        colActionBooking.setCellFactory(new Callback<>() {
            @Override
            public TableCell<Booking, Void> call(TableColumn<Booking, Void> param) {
                return new TableCell<>() {
                    private final Button btn = new Button("Konfirmasi");
                    {
                        btn.getStyleClass().add("btn-table-action");
                        btn.setOnAction(e -> handleKonfirmasi(getTableView().getItems().get(getIndex())));
                    }
                    @Override
                    protected void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        setGraphic(empty ? null : btn);
                    }
                };
            }
        });
    }

    private void loadDummyData() {
        ObservableList<Transaksi> dataTransaksi = FXCollections.observableArrayList(
                new Transaksi("TR_001", "Reguler 1", "1 Jam", "Gyan", "Rp45.000"),
                new Transaksi("TR_002", "VVIP 2", "2 Jam", "Aluna", "Rp150.000"),
                new Transaksi("TR_003", "Family 1", "1 Jam", "Hidayat", "Rp100.000")
        );
        tableTransaksi.setItems(dataTransaksi);

        ObservableList<Booking> dataBooking = FXCollections.observableArrayList(
                new Booking("BK_001", "Reguler 1", "1 Jam", "Gyan", "Rp45.000"),
                new Booking("BK_002", "VVIP 2", "2 Jam", "Aluna", "Rp150.000"),
                new Booking("BK_003", "Family 1", "1 Jam", "Hidayat", "Rp100.000")
        );
        tableBooking.setItems(dataBooking);
    }

    private void handleTambahOrder(Transaksi data) {
        System.out.println("Tambah order untuk: " + data.getIdTransaksi());
        // TODO: buka halaman/dialog tambah order F&B
    }

    private void handleKonfirmasi(Booking data) {
        System.out.println("Konfirmasi booking: " + data.getIdBooking());
        // TODO: update status booking ke "confirmed" di database
    }

    @FXML private void handleTransaksiBaru(ActionEvent e) { /* TODO buka form transaksi baru */ }
    @FXML private void showTransaksiAktif(ActionEvent e) { }
    @FXML private void showTransaksiBooking(ActionEvent e) { }
    @FXML private void showTransaksiOrderFnb(ActionEvent e) { }
    @FXML private void showTransaksiPembayaran(ActionEvent e) { }
    @FXML private void showCustomer(ActionEvent e) { }
    @FXML private void showLaporan(ActionEvent e) { }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}