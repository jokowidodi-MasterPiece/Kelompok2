package org.example.karaokeapp.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class RegisterController {

    @FXML private TextField namaLengkapField;
    @FXML private ComboBox<String> posisiComboBox;
    @FXML private TextField nomorTlpField;
    @FXML private TextField alamatField;
    @FXML private TextField emailField;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    @FXML
    public void initialize() {
        posisiComboBox.getItems().addAll("Admin", "Kasir");
    }

    @FXML
    private void handleRegister(ActionEvent event) {
        if (namaLengkapField.getText().isEmpty()
                || posisiComboBox.getValue() == null
                || usernameField.getText().isEmpty()
                || passwordField.getText().isEmpty()) {
            System.out.println("Lengkapi data dulu!");
            return;
        }

        // TODO: simpan data karyawan baru ke database
        // namaLengkapField.getText(), posisiComboBox.getValue(), nomorTlpField.getText(),
        // alamatField.getText(), emailField.getText(), usernameField.getText(), passwordField.getText()

        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}