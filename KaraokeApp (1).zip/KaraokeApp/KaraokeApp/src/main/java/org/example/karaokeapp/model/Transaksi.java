package org.example.karaokeapp.model;

public class Transaksi {
    private String idTransaksi, room, durasi, customer, subtotal;

    public Transaksi(String idTransaksi, String room, String durasi, String customer, String subtotal) {
        this.idTransaksi = idTransaksi;
        this.room = room;
        this.durasi = durasi;
        this.customer = customer;
        this.subtotal = subtotal;
    }

    public String getIdTransaksi() { return idTransaksi; }
    public String getRoom() { return room; }
    public String getDurasi() { return durasi; }
    public String getCustomer() { return customer; }
    public String getSubtotal() { return subtotal; }
}