package org.example.karaokeapp.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.karaokeapp.DBConnect.DBConnectZeramix;

import java.sql.*;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        // Validasi field kosong
        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Username dan password tidak boleh kosong.");
            return;
        }

        try {
            // Panggil stored procedure login
            DBConnectZeramix db = new DBConnectZeramix();
            CallableStatement cs = db.conn.prepareCall("{call sp_LoginKaryawan(?, ?)}");
            cs.setString(1, username);
            cs.setString(2, password);
            ResultSet rs = cs.executeQuery();

            if (rs.next()) {
                // Login berhasil, ambil data karyawan
                String nama   = rs.getString("Nama");
                String posisi = rs.getString("Posisi");

                // Tentukan dashboard sesuai posisi
                String fxmlPath;
                switch (posisi.toLowerCase()) {
                    case "admin"   -> fxmlPath = "/view/DashboardAdmin.fxml";
                    case "kasir"   -> fxmlPath = "/view/DashboardKasir.fxml";
                    case "manajer" -> fxmlPath = "/view/DashboardManajer.fxml";
                    default -> {
                        errorLabel.setText("Posisi tidak dikenali: " + posisi);
                        return;
                    }
                }

                // Load dashboard tujuan
                FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
                Parent root = loader.load();

                // Kirim nama & posisi ke controller dashboard tujuan
                switch (posisi.toLowerCase()) {
                    case "admin" -> {
                        DashboardAdminController ctrl = loader.getController();
                        ctrl.setDataKaryawan(nama, posisi);
                    }
//                    case "kasir" -> {
//                        DashboardKasirController ctrl = loader.getController();
//                        ctrl.setDataKaryawan(nama, posisi);
//                    }
                }

                // Pindah scene
                Stage stage = (Stage) usernameField.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.setMaximized(true);
                stage.show();

            } else {
                // Login gagal
                errorLabel.setText("Username atau password salah / akun tidak aktif.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            errorLabel.setText("Gagal terhubung ke database.");
        }
    }
}