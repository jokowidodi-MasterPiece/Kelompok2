package org.example.karaokeapp.model;

public class Karyawan {
    private int idKaryawan;
    private String nama, posisi, alamat, email, nomorTelepon, username, password, status;

    public Karyawan(int idKaryawan, String nama, String posisi, String alamat,
                    String email, String nomorTelepon, String username,
                    String password, String status) {
        this.idKaryawan = idKaryawan;
        this.nama = nama;
        this.posisi = posisi;
        this.alamat = alamat;
        this.email = email;
        this.nomorTelepon = nomorTelepon;
        this.username = username;
        this.password = password;
        this.status = status;
    }

    public int getIdKaryawan()      { return idKaryawan; }
    public String getNama()         { return nama; }
    public String getPosisi()       { return posisi; }
    public String getAlamat()       { return alamat; }
    public String getEmail()        { return email; }
    public String getNomorTelepon() { return nomorTelepon; }
    public String getUsername()     { return username; }
    public String getPassword()     { return password; }
    public String getStatus()       { return status; }

    public void setIdKaryawan(int idKaryawan)      { this.idKaryawan = idKaryawan; }
    public void setNama(String nama)               { this.nama = nama; }
    public void setPosisi(String posisi)           { this.posisi = posisi; }
    public void setAlamat(String alamat)           { this.alamat = alamat; }
    public void setEmail(String email)             { this.email = email; }
    public void setNomorTelepon(String nomorTelepon){ this.nomorTelepon = nomorTelepon; }
    public void setUsername(String username)        { this.username = username; }
    public void setPassword(String password)        { this.password = password; }
    public void setStatus(String status)            { this.status = status; }
}