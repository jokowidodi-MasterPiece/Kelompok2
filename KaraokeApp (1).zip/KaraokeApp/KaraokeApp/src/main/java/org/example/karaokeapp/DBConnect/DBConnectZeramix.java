package org.example.karaokeapp.DBConnect;

import java.sql.*;

public class DBConnectZeramix {
    public Connection conn;
    public Statement stat;
    public ResultSet result;
    public PreparedStatement pstat;

    public DBConnectZeramix(){
        try{
            String url = "jdbc:sqlserver://DESKTOP-9M7VCUS\\SQLEXPRESS:1433;"+
                    "databaseName=Zeramixgrow;"+
                    "user=sa;"+
                    "password=admin;"+
                    "trustServerCertificate=true;";

            conn = DriverManager.getConnection(url);
            stat = conn.createStatement();
        }catch(Exception e){
            System.out.println("Error saat connect database"+ e);
        }
    }
    public static void main (String[] args){
        DBConnectZeramix connection = new DBConnectZeramix();
        System.out.println("Connecting to Database succesfully");
    }
}
