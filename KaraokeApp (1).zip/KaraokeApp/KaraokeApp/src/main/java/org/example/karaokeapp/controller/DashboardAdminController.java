package org.example.karaokeapp.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.karaokeapp.DBConnect.DBConnectZeramix;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DashboardAdminController {

    @FXML private BorderPane rootPane;
    @FXML private Label namaLabel;
    @FXML private Label roleLabel;
    @FXML private Label loginTerakhirLabel;
    @FXML private Label totalRoomLabel;
    @FXML private Label karyawanAktifLabel;
    @FXML private Label customerTerdaftarLabel;
    @FXML private VBox activityContainer;

    @FXML private Button btnDashboard;
    @FXML private Button btnRoom;
    @FXML private Button btnKaryawan;
    @FXML private Button btnMenuFnb;
    @FXML private Button btnInventaris;
    @FXML private Button btnCustomer;
    @FXML private Button btnDenda;
    @FXML private Button btnLaporan;
    @FXML private Button btnLogout;

    private Button[] menuButtons;
    private int selectedIndex = 0;

    @FXML
    public void initialize() {
        menuButtons = new Button[]{
                btnDashboard, btnRoom, btnKaryawan, btnMenuFnb,
                btnInventaris, btnCustomer, btnDenda, btnLaporan
        };

        updateSelection();

        // Pasang key listener setelah scene benar-benar siap
        rootPane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                // Tambahkan filter di scene level (FILTER bukan handler)
                // supaya selalu ditangkap meski fokus ada di button manapun
                newScene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
                    if (event.getCode() == KeyCode.UP) {
                        if (selectedIndex > 0) {
                            selectedIndex--;
                            updateSelection();
                        }
                        event.consume(); // cegah scroll default
                    } else if (event.getCode() == KeyCode.DOWN) {
                        if (selectedIndex < menuButtons.length - 1) {
                            selectedIndex++;
                            updateSelection();
                        }
                        event.consume();
                    } else if (event.getCode() == KeyCode.ENTER) {
                        menuButtons[selectedIndex].fire();
                        event.consume();
                    }
                });

                // Minta fokus ke rootPane setelah scene tampil
                javafx.application.Platform.runLater(() -> rootPane.requestFocus());
            }
        });
    }

    private void updateSelection() {
        for (Button btn : menuButtons) {
            btn.getStyleClass().remove("sidebar-item-active");
            if (!btn.getStyleClass().contains("sidebar-item")) {
                btn.getStyleClass().add("sidebar-item");
            }
        }

        Button aktif = menuButtons[selectedIndex];
        aktif.getStyleClass().remove("sidebar-item");
        aktif.getStyleClass().add("sidebar-item-active");

        // Gunakan Platform.runLater agar fokus tidak rebutan dengan event
        javafx.application.Platform.runLater(() -> rootPane.requestFocus());
    }

    private void loadPage(String path) {
        try {
            Parent page = FXMLLoader.load(getClass().getResource(path));
            rootPane.setCenter(page);
            // Kembalikan fokus ke rootPane setelah halaman dimuat
            javafx.application.Platform.runLater(() -> rootPane.requestFocus());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setDataKaryawan(String nama, String posisi) {
        namaLabel.setText(nama.toUpperCase());
        roleLabel.setText(posisi);
        loginTerakhirLabel.setText("Login Terakhir : " +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm")));
        loadStatistik();
        loadAktivitas();
    }

    private void loadStatistik() {
        try {
            DBConnectZeramix db = new DBConnectZeramix();
            Statement st = db.conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT dbo.fn_TotalKaryawanAktif()");
            if (rs.next()) karyawanAktifLabel.setText(String.valueOf(rs.getInt(1)));

            rs = st.executeQuery("SELECT COUNT(*) FROM Room");
            if (rs.next()) totalRoomLabel.setText(String.valueOf(rs.getInt(1)));

            rs = st.executeQuery("SELECT COUNT(*) FROM Customer");
            if (rs.next()) customerTerdaftarLabel.setText(String.valueOf(rs.getInt(1)));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAktivitas() {
        try {
            DBConnectZeramix db = new DBConnectZeramix();
            Statement st = db.conn.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT TOP 5 Keterangan, Waktu FROM Log_Karyawan ORDER BY Waktu DESC"
            );

            activityContainer.getChildren().clear();

            while (rs.next()) {
                String keterangan = rs.getString("Keterangan");
                String waktu = rs.getTimestamp("Waktu")
                        .toLocalDateTime()
                        .format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm"));

                HBox row = new HBox(10);
                row.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

                Label diamond = new Label("◆");
                diamond.setStyle("-fx-text-fill:#7A2840;");

                Label ket = new Label(keterangan);
                ket.getStyleClass().add("activity-item");
                HBox.setHgrow(ket, Priority.ALWAYS);

                Label waktuLabel = new Label(waktu);
                waktuLabel.getStyleClass().add("activity-time");

                row.getChildren().addAll(diamond, ket, waktuLabel);
                activityContainer.getChildren().add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void showDashboard(ActionEvent event) {
        selectedIndex = 0;
        updateSelection();
        // Kosongkan center kembali ke dashboard default
        rootPane.setCenter(null);
    }

    @FXML
    private void showRoom(ActionEvent event) {
        selectedIndex = 1;
        updateSelection();
        loadPage("/Master/MasterRoom.fxml");
    }

    @FXML
    private void showKaryawan(ActionEvent event) {
        selectedIndex = 2;
        updateSelection();
        loadPage("/Master/MasterKaryawan.fxml");
    }

    @FXML
    private void showMenuFnb(ActionEvent event) {
        selectedIndex = 3;
        updateSelection();
        loadPage("/Master/MasterMenuFnb.fxml");
    }

    @FXML
    private void showInventaris(ActionEvent event) {
        selectedIndex = 4;
        updateSelection();
        loadPage("/Master/MasterInventaris.fxml");
    }

    @FXML
    private void showCustomer(ActionEvent event) {
        selectedIndex = 5;
        updateSelection();
        loadPage("/Master/MasterCustomer.fxml");
    }

    @FXML
    private void showDenda(ActionEvent event) {
        selectedIndex = 6;
        updateSelection();
        loadPage("/Master/MasterDenda.fxml");
    }

    @FXML
    private void showLaporan(ActionEvent event) {
        selectedIndex = 7;
        updateSelection();
        loadPage("/Master/Laporan.fxml");
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setMaximized(true);
        stage.show();
    }
}