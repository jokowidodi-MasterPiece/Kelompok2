package org.example.karaokeapp.ControlMaster;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.karaokeapp.DBConnect.DBConnectZeramix;
import org.example.karaokeapp.model.Karyawan;

import java.sql.*;

public class MasterKaryawanController {

    @FXML private TextField namaTF, alamatTF, emailTF, teleponTF, usernameTF;
    @FXML private PasswordField passwordTF;
    @FXML private ComboBox<String> posisiCB, statusCB;
    @FXML private TableView<Karyawan> tabelKaryawan;
    @FXML private TableColumn<Karyawan, Integer> colId;
    @FXML private TableColumn<Karyawan, String> colNama, colPosisi, colAlamat,
            colEmail, colTelepon, colUsername, colStatus;
    @FXML private Label pesanLabel;

    private Karyawan karyawanDipilih = null;

    @FXML
    public void initialize() {
        posisiCB.setItems(FXCollections.observableArrayList("Admin", "Kasir", "Manajer"));
        statusCB.setItems(FXCollections.observableArrayList("Aktif", "Non-Aktif"));

        // Mapping kolom
        colId.setCellValueFactory(new PropertyValueFactory<>("idKaryawan"));
        colNama.setCellValueFactory(new PropertyValueFactory<>("nama"));
        colPosisi.setCellValueFactory(new PropertyValueFactory<>("posisi"));
        colAlamat.setCellValueFactory(new PropertyValueFactory<>("alamat"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colTelepon.setCellValueFactory(new PropertyValueFactory<>("nomorTelepon"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        setCellTextColor(colId);
        setCellTextColor(colNama);
        setCellTextColor(colPosisi);
        setCellTextColor(colAlamat);
        setCellTextColor(colEmail);
        setCellTextColor(colTelepon);
        setCellTextColor(colUsername);
        setCellTextColor(colStatus);

        // Batasi input telepon hanya angka max 13 karakter
        teleponTF.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) {
                teleponTF.setText(newVal.replaceAll("[^\\d]", ""));
            }
            if (teleponTF.getText().length() > 13) {
                teleponTF.setText(teleponTF.getText().substring(0, 13));
            }
        });

        loadTabel();

        // Klik baris tabel → isi form
        tabelKaryawan.getSelectionModel().selectedItemProperty().addListener((obs, old, k) -> {
            if (k != null) {
                karyawanDipilih = k;
                namaTF.setText(k.getNama());
                posisiCB.setValue(k.getPosisi());
                alamatTF.setText(k.getAlamat());
                emailTF.setText(k.getEmail());
                teleponTF.setText(k.getNomorTelepon());
                usernameTF.setText(k.getUsername());
                passwordTF.setText(k.getPassword());
                statusCB.setValue(k.getStatus());
            }
        });
    }

    // ===================== LOAD TABEL =====================
    private void loadTabel() {
        ObservableList<Karyawan> list = FXCollections.observableArrayList();
        try {
            DBConnectZeramix db = new DBConnectZeramix();
            CallableStatement cs = db.conn.prepareCall("{call sp_LihatKaryawan()}");
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                list.add(new Karyawan(
                        rs.getInt("ID_Karyawan"),
                        rs.getString("Nama"),
                        rs.getString("Posisi"),
                        rs.getString("Alamat"),
                        rs.getString("Email"),
                        rs.getString("Nomor_telepon"),
                        rs.getString("Username"),
                        rs.getString("Password"),
                        rs.getString("Status")
                ));
            }
            tabelKaryawan.setItems(list);
            tabelKaryawan.refresh();

            // Force warna teks setelah JavaFX selesai render
            Platform.runLater(() -> {
                tabelKaryawan.lookupAll(".table-cell").forEach(node ->
                        node.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 13px;")
                );
            });

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Gagal Memuat Data",
                    "Tidak bisa mengambil data karyawan.\n" + e.getMessage());
        }
    }

    // ===================== TAMBAH =====================
    @FXML
    private void handleTambah() {
        if (!validasi()) return;
        try {
            DBConnectZeramix db = new DBConnectZeramix();
            CallableStatement cs = db.conn.prepareCall("{call sp_TambahKaryawan(?,?,?,?,?,?,?,?)}");
            cs.setString(1, namaTF.getText().trim());
            cs.setString(2, posisiCB.getValue());
            cs.setString(3, alamatTF.getText().trim());
            cs.setString(4, emailTF.getText().trim());
            cs.setString(5, teleponTF.getText().trim());
            cs.setString(6, usernameTF.getText().trim());
            cs.setString(7, passwordTF.getText());
            cs.setString(8, statusCB.getValue() != null ? statusCB.getValue() : "Aktif");
            cs.executeUpdate();

            showAlert(Alert.AlertType.INFORMATION, "Berhasil",
                    "Karyawan \"" + namaTF.getText().trim() + "\" berhasil ditambahkan.");
            handleReset();
            loadTabel();
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Gagal Tambah",
                    "Terjadi kesalahan saat menambah karyawan.\n" + e.getMessage());
        }
    }

    // ===================== UPDATE =====================
    @FXML
    private void handleUpdate() {
        if (karyawanDipilih == null) {
            showAlert(Alert.AlertType.WARNING, "Perhatian",
                    "Pilih karyawan di tabel terlebih dahulu.");
            return;
        }
        if (!validasi()) return;
        try {
            DBConnectZeramix db = new DBConnectZeramix();
            CallableStatement cs = db.conn.prepareCall("{call sp_UbahKaryawan(?,?,?,?,?,?,?,?,?)}");
            cs.setInt(1, karyawanDipilih.getIdKaryawan());
            cs.setString(2, namaTF.getText().trim());
            cs.setString(3, posisiCB.getValue());
            cs.setString(4, alamatTF.getText().trim());
            cs.setString(5, emailTF.getText().trim());
            cs.setString(6, teleponTF.getText().trim());
            cs.setString(7, usernameTF.getText().trim());
            cs.setString(8, passwordTF.getText());
            cs.setString(9, statusCB.getValue());
            cs.executeUpdate();

            showAlert(Alert.AlertType.INFORMATION, "Berhasil",
                    "Data karyawan \"" + namaTF.getText().trim() + "\" berhasil diperbarui.");
            handleReset();
            loadTabel();
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Gagal Update",
                    "Terjadi kesalahan saat memperbarui data.\n" + e.getMessage());
        }
    }

    // ===================== HAPUS =====================
    @FXML
    private void handleHapus() {
        if (karyawanDipilih == null) {
            showAlert(Alert.AlertType.WARNING, "Perhatian",
                    "Pilih karyawan di tabel terlebih dahulu.");
            return;
        }

        // Konfirmasi sebelum hapus
        Alert konfirmasi = new Alert(Alert.AlertType.CONFIRMATION);
        konfirmasi.setTitle("Konfirmasi Hapus");
        konfirmasi.setHeaderText(null);
        konfirmasi.setContentText("Yakin ingin menonaktifkan karyawan \"" +
                karyawanDipilih.getNama() + "\"?");
        konfirmasi.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    DBConnectZeramix db = new DBConnectZeramix();
                    CallableStatement cs = db.conn.prepareCall("{call sp_HapusKaryawan(?)}");
                    cs.setInt(1, karyawanDipilih.getIdKaryawan());
                    cs.executeUpdate();

                    showAlert(Alert.AlertType.INFORMATION, "Berhasil",
                            "Karyawan \"" + karyawanDipilih.getNama() + "\" berhasil dinonaktifkan.");
                    handleReset();
                    loadTabel();
                } catch (Exception e) {
                    showAlert(Alert.AlertType.ERROR, "Gagal Hapus",
                            "Terjadi kesalahan saat menghapus data.\n" + e.getMessage());
                }
            }
        });
    }

    // ===================== RESET =====================
    @FXML
    private void handleReset() {
        karyawanDipilih = null;
        namaTF.clear();
        alamatTF.clear();
        emailTF.clear();
        teleponTF.clear();
        usernameTF.clear();
        passwordTF.clear();
        posisiCB.setValue(null);
        statusCB.setValue(null);
        pesanLabel.setText("");
        tabelKaryawan.getSelectionModel().clearSelection();
    }

    // ===================== VALIDASI =====================
    private boolean validasi() {
        String nama     = namaTF.getText().trim();
        String email    = emailTF.getText().trim();
        String telepon  = teleponTF.getText().trim();
        String username = usernameTF.getText().trim();
        String password = passwordTF.getText();

        // Wajib isi
        if (nama.isEmpty() || posisiCB.getValue() == null ||
                username.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Validasi Gagal",
                    "Nama, Posisi, Username, dan Password wajib diisi.");
            return false;
        }

        // Validasi email
        if (!email.isEmpty() && !email.matches("^[\\w.+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$")) {
            showAlert(Alert.AlertType.WARNING, "Validasi Gagal",
                    "Format email tidak valid.\nContoh yang benar: nama@gmail.com");
            return false;
        }

        // Validasi telepon
        if (!telepon.isEmpty()) {
            if (!telepon.matches("\\d+")) {
                showAlert(Alert.AlertType.WARNING, "Validasi Gagal",
                        "Nomor telepon hanya boleh berisi angka.");
                return false;
            }
            if (telepon.length() > 13) {
                showAlert(Alert.AlertType.WARNING, "Validasi Gagal",
                        "Nomor telepon maksimal 13 digit.");
                return false;
            }
        }

        return true;
    }

    // ===================== ALERT HELPER =====================
    private void showAlert(Alert.AlertType type, String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(type);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private <T> void setCellTextColor(TableColumn<Karyawan, T> col) {
        col.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item.toString());
                    setStyle("-fx-text-fill: #333333; -fx-font-size: 13px;");
                }
            }
        });
    }
}