module org.example.karaokeapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires com.microsoft.sqlserver.jdbc;

    exports org.example.karaokeapp to javafx.graphics, javafx.fxml;

    opens org.example.karaokeapp to javafx.fxml, javafx.graphics;
    opens org.example.karaokeapp.controller to javafx.fxml;
    opens org.example.karaokeapp.ControlMaster to javafx.fxml;
    opens org.example.karaokeapp.model to javafx.fxml;
    opens org.example.karaokeapp.DBConnect to javafx.fxml;
}